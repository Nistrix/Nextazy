package io.nextazy.authentication.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityAutenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
