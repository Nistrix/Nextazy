package io.nextazy.authentication.security.user;

public enum Role {
	
	USER,
	ADMIN

}
